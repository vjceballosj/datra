package com.inceji.datra.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ModbusConfig {
    // Aquí se integrará el cliente DigitalPetri u otra lib Modbus TCP
    // Ejemplo: conexión al Arduino Opta para leer PM130
}

