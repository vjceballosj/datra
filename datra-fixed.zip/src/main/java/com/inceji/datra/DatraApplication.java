package com.inceji.datra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatraApplication {
    public static void main(String[] args) {
        SpringApplication.run(DatraApplication.class, args);
    }
}