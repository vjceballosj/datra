package com.inceji.datra.enums;

public enum CommandStatus {
    PENDING,
    SUCCESS,
    FAILED
}
