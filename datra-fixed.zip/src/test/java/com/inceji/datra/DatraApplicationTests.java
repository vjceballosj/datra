package com.inceji.datra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatraApplicationTests {

	@Test
	void contextLoads() {
	}

}
